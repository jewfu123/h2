package com.codetech.authserver.model;

public class IntrospectResponse {

	private Boolean active;

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}
}
